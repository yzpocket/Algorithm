package common;

public class EmptyException extends RuntimeException {
	
	public EmptyException() {
		super("EmptyException");//예외 메시지
	}

}
