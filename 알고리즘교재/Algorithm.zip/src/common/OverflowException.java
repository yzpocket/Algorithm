package common;

public class OverflowException extends RuntimeException{
	
	public OverflowException() {
		super("OverflowException");
	}

}
